﻿namespace BeautySaloon
{
    public class HairAccessory : ItemBase
    {
        public override string Title => "Аксессуары для волос";
        public override int Price => 40;
    }
}
