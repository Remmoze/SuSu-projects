﻿namespace BeautySaloon
{
    public class HairAccessory : ItemBase
    {
        public override int Price
        {
            get
            {
                return 40;
            }
        }
    }
}
