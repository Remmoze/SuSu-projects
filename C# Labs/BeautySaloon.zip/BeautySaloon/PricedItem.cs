﻿namespace BeautySaloon
{

}
